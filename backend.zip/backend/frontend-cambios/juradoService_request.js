// En Parte_Jurado/assets/services/juradoService.js, REEMPLAZA la funcion request() por esta.
// Cambio: ahora envia el token en cada peticion, para que el backend sepa quien es el jurado.
async function request(path, options = {}) {
  let token = "";
  try {
    token = JSON.parse(window.localStorage.getItem("etitc-session") || "null")?.token || "";
  } catch {
    token = "";
  }

  const response = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: { ...(options.headers || {}), Authorization: `Bearer ${token}` }
  });

  if (!response.ok) {
    throw new Error(`API error ${response.status}`);
  }
  return response.json();
}
