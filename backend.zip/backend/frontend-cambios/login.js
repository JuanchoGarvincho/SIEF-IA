// REEMPLAZA el contenido de LOGIN/login.js por este archivo.
// Cambio: en vez de guardar cualquier correo, ahora se valida contra el backend.
document.addEventListener("DOMContentLoaded", () => {
  const roleSelect = document.getElementById("rol");
  const note = document.getElementById("loginNote");
  const form = document.getElementById("loginForm");

  if (!roleSelect || !note || !form) {
    return;
  }

  const API_BASE = "http://localhost:3000"; // dirección del backend

  const params = new URLSearchParams(window.location.search);
  const roleParam = params.get("rol");

  if (roleParam === "jurado" || roleParam === "estudiantes") {
    roleSelect.value = roleParam;
  }

  const updateNote = () => {
    note.textContent = roleSelect.value === "jurado"
      ? "Solo jurados y coordinadores autorizados pueden ingresar a este modulo."
      : "Solo estudiantes y docentes autorizados pueden ingresar a este modulo.";
  };

  updateNote();
  roleSelect.addEventListener("change", updateNote);

  form.addEventListener("submit", async (event) => {
    event.preventDefault();

    const role = roleSelect.value;
    const correo = document.getElementById("correo")?.value.trim() || "";
    const clave = document.getElementById("clave")?.value || "";

    try {
      const response = await fetch(`${API_BASE}/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ correo, clave, rol: role })
      });
      const data = await response.json();

      if (!response.ok) {
        note.textContent = data.error || "No se pudo iniciar sesion.";
        return;
      }

      // Guardamos el token (la "llave" de la sesion) y la direccion del backend.
      // Al existir "etitc-api-base", juradoService.js deja de usar datos de mentira.
      localStorage.setItem("etitc-api-base", API_BASE);
      localStorage.setItem("etitc-session", JSON.stringify({
        rol: role,
        correo: data.usuario.correo,
        token: data.token
      }));

      window.location.href = role === "jurado"
        ? "../Parte_Jurado/panel/index.html"
        : "../Parte_Estudiantes/INSCRIPCION/index.html";
    } catch (error) {
      note.textContent = "No se pudo conectar con el servidor. Esta encendido el backend?";
    }
  });
});
